# Claude Token Firebreak

Package Claude Code pour audits volumineux. Il empêche les données brutes de saturer la conversation principale grâce à un inventaire mécanique, des shards logiques, des subagents isolés, une vérification indépendante, des sorties JSON bornées et un stockage sous `.firebreak/`.

## Prérequis

- Windows PowerShell ;
- Python 3.9+ sans dépendance externe ;
- Claude Code 2.1.154+ pour les dynamic workflows ;
- accès Claude Code compatible avec les workflows.

## Démarrage

Après installation à la racine du dépôt audité :

```powershell
python scripts/validate_package.py .
python scripts/inventory.py . --config config/firebreak.json --out .firebreak/manifest.json
python scripts/shard.py .firebreak/manifest.json --config config/firebreak.json --out .firebreak/shards
```

Dans Claude Code, lancer :

```text
/token-firebreak auditer le dépôt pour les défauts de sécurité et de fiabilité
```

Le skill peut ensuite lancer le workflow réutilisable `/token-firebreak-audit`. Le workflow accepte un objet contenant `objective` et `maxShards`; la valeur par défaut est 10 shards afin de borner le coût.

## Livrables d’un audit

```text
.firebreak/
├── manifest.json
├── shards/
├── raw-findings/
├── verified-findings/
├── rejected/
├── evidence/
├── tool-output/
├── reports/audit-report.md
├── runtime.json
└── metrics.json
```

Les seuils de [config/firebreak.json](config/firebreak.json) sont une politique locale, pas des limites Anthropic. Ils doivent être calibrés par un benchmark A/B.

## Documentation

- [Runbook complet](TOKEN-FIREBREAK.md)
- [Guide de fonctionnement détaillé](GUIDE-FONCTIONNEMENT.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Installation](docs/INSTALLATION.md)
- [Benchmark A/B](docs/BENCHMARK.md)
- [Sources Anthropic officielles](docs/OFFICIAL-SOURCES.md)

Le package n’autorise aucune modification du code audité. Les agents écrivent uniquement sous `.firebreak/`.
